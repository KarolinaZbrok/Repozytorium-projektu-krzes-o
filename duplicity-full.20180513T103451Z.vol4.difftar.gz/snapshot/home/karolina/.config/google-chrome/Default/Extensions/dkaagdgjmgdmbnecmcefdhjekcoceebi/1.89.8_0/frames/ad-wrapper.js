function getParameterByName(name, url) {
	if (!url) url = window.location.href;
	name = name.replace(/[\[\]]/g, "\\$&");
	var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
		results = regex.exec(url);
	if (!results) return null;
	if (!results[2]) return '';
	return decodeURIComponent(results[2].replace(/\+/g, " "));
}

var iframeMessagePrefix = getParameterByName('iframeMessagePrefix');
var srcdoc = getParameterByName('srcdoc');

// Piping message to parent iframe
window.addEventListener('message', event => {
	if(!event.data) {
		return;
	}
	parent.postMessage(event.data, "*");
});

var iframe = document.createElement('iframe');
iframe.name = 'chromeperfectpixel-ad-window';
iframe.sandbox = 'allow-scripts';
iframe['referrer-policy'] = 'no-referrer';
iframe.srcdoc = srcdoc;
iframe.style = 'position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0;';
document.body.appendChild(iframe);