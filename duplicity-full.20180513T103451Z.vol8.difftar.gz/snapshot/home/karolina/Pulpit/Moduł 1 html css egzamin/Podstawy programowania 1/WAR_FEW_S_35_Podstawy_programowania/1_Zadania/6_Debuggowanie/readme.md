<img alt="Logo" src="http://coderslab.pl/svg/logo-coderslab.svg" width="400">

# Debuggowanie  &ndash; zadania

> Pamiętaj, żeby oddzielać ćwiczenia komentarzami i pisać czytelny, dobrze sformatowany kod.

-------------------------------------------------------------------------------
## Zadania do samodzielnego wykonania

### Szukanie błędów (~ 10min - 15min)
W plikach **zadanie01.js** i **zadanie02.js**  znajdziesz niedziałający kod. Twoim zadaniem jest znalezienie błędów. Wykorzystaj zdobytą wiedzę i użyj znanego Ci narzędzia do debugowania.
