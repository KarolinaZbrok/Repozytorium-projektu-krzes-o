

var array = [2, 3, 1, 6, 100, 49, 5, 7, 8, 9];

function getSecondMaxNumber(array) {

    return array.sort(function (a, b) {
        return b - a;
    } ) [1];


    }

console.log( getSecondMaxNumber( array ) )

