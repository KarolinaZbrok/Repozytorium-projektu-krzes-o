
    function getEvenSum(n)
    {
        var sumEven = 0;

        for(var i = 1; i <= n; i++)
        {
            if(i % 2 == 0)
            {
                sumEven = sumEven + i;
            }
        }
        return sumEven;
    }
    console.log(getEvenSum(6));
