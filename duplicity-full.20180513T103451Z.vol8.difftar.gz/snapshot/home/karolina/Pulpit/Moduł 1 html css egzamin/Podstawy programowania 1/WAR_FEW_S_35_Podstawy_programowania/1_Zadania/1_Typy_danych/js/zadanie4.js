//String + number
var text = "Ala ma kota";
var number = 87;

var resultAddTextToNumber = text + number;
console.log(typeof resultAddTextToNumber);
// Wynik: Ala ma kota87 -> String
