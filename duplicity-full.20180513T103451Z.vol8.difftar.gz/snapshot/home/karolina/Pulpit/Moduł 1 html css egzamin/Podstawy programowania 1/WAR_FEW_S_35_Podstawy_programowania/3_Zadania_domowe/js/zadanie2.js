


var array = [ 4, -5, 0, 2, -67, 8, 10, -34 ];

function getNegativeNumbers( array ) {
    return array.filter( function( neg ) {
        return neg < 0;
    } );
}

console.log( getNegativeNumbers( array ) );