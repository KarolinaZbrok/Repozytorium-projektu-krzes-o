//Z 1



var numbers = [33, 342, 969];
	for (var i=0; i < numbers.length; i++) {
   console.log( numbers[i] );
}	

// Z 2

var fruits = ["jabo", "śliwa", "czereśnia", "mandarynka"];
console.log(fruits[0]);

		var fruits = ["jabo", "śliwa", "czereśnia", "mandarynka"];
   console.log(fruits[fruits.length-1]);
	

	
		var fruits = ["jabo", "śliwa", "czereśnia", "mandarynka"];
	for (var i=0; i < fruits.length; i++) {
   console.log( fruits[i] );
		}	


// Z3 - zrobione - wyświetla wynik całościowy w ostatniej linii, sumuje sobie cząstkowo,  nie psuć!!!

var number1 = [1, 58, 55, 41, 78, 89, 100, 12, 47, 36] ;
var sum = 0;
		for (i=0; i<number1.length ; i++)
			{console.log( sum = sum + number1[i] );
			}
		
	
// Z4 - zrobione, wyświetla analogicznie jak wyżej
	
	var number2 = [1, 58, 55, 41, 78, 89, 100, 12, 47, 36] ;
	var sum = 0;
	for (i=0; i<number2.length ; i++)
			if (number2[i]%2==0)
		{console.log(sum= sum+=number2[i]);} 
		
		
//Z5 	dobrze, nie psuć!!!!!

		
		var number3 = [1, 58, 55, 41, 78, 89, 100, 12, 47, 36] ;
	var max= 0;
				for (i=0; i<number3.length ; i++)
								if (max<number3[i]) {max=number3[i];}
					
				console.log(max);
				
				
			

// Z 6 - poniżej dobrze

	var arrWithNumbers = [2, 4, 5, 2, 3, 5, 1, 2, 4];
	var firstIndex=0;
		
		for (i=0; i<arrWithNumbers.length; i++) {
		
		for(j=(i+1); j<arrWithNumbers.length; j++) 
			{	if(arrWithNumbers[i]==arrWithNumbers[j]) {
						 firstIndex=arrWithNumbers[i];
							break;
						}		
				}					
		}
console.log(firstIndex);		


// Z7 - poniżej dobrze
				
		
var number4 = [1, 58, 55, 41, 78, 89, 100, 12, 47, 36] ;			
			for (var i = number4.length-1; i>=0; i--)
			{ 
					console.log(number4[i]);
			}		
		
