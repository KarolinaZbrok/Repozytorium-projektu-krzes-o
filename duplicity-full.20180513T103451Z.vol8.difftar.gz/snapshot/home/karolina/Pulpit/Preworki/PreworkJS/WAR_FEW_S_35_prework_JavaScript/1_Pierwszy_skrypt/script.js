console.log("Karolina");

// Zadanie 2
// 1. Poprawne wyświetlenie poprawnego wyniku
// 2. Poprawne wyświetlenie poprawnego wyniku
// 3. Poprawne wyświetlenie poprawnego wyniku

// Zadanie 3
// 4. Poprawne wyświetlenie tekstu
// 5. Niepoprawne wyświetlenie tekstu - błąd "unexpected identifier"
// 6. Niepoprawne wyświetlenie tekstu - błąd "invalid or unexpected token"
