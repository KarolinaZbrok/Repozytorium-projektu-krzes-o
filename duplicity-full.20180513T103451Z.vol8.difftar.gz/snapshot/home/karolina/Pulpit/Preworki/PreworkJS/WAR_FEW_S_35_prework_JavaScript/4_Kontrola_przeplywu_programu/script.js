
// Zadanie 7

/*
 Pętla zewnętrzna z licznikiem o zmiennej ```i``` zajmuje się
wierszami, a pętla wewnętrzna z licznikiem o zmiennej ```j``` zajmuje się kolumnami.
Zaczynamy od lewej górnej gwiazdki i przemieszczamy się w prawo będąc w pierwszym wierszu.
Kiedy pętla wewnętrzna dojdzie do ostatniej kolumny, kończy działanie. Wtedy pętla zewnętrzna
zwiększa licznik o 1 (przechodzi do kolejnego wiersza) i tak dalej.
*/

//Zmienna, przechowująca wielkość naszego kwadratu
var size = 5;

//Zmienna przechowująca jedną linię gwiazdek
var lineOfStars = "";

for(var i = 0; i < size; i++) {
    // W każdym kroku muszę zresetować zmienną, ponieważ zaczcynam tworzenie nowej linii
    lineOfStars = "";
    for(var j = 0; j < size; j++) {
        //Do zmiennej lineOfStars dodaje gwiazdkę
        lineOfStars = lineOfStars + "*";
    }
    // Oddzielam kazdą linię, pustym wierszem, ponieważ przeglądarka widząc 5 takich samych
    //wyników zwinie nasz kwadrat z gwiazdek do jednej linijki
    console.log(" ");

    //Wypisuje w konsoli zmienną lineOfStars (jej zawartość - dlatego jest bez cudzysłosów)
    console.log(lineOfStars);
}





var number1=200;
console.log(number1);

var number2=200;
console.log(number2);

if (number1>number2) 
		{console.log("Pierwsza liczba jt większa od drugiej");}
	else if (number1<number2) 
			{console.log("Druga liczba jt większa od pierwszej");}
			else {console.log("Liczby są równe")}
			
//Testowane, pisze sensownie

var number1=200;
console.log(number1);

var number2=2000;
console.log(number2);

var number3=300
console.log(number3);

if (number1>number2&&number1>number3) 
		{console.log("Pierwsza liczba jt największa");}
	else if (number1<number2&&number2<number3) 
			{console.log("Trzecia liczba jt największa");}
			else {console.log("Druga liczba jt największa")}
			
//Testowane, pisze sensownie


for(var i=0; i<10; i=i+1)
{console.log("Lubię javaScript");}

//Testowane, pisze sensownie

//Z 4 zrobione


var suma = 0;
for (var i = 1; i <= 10; i++)
    suma = suma + i;
console.log(suma)



//Z 5 zrobione, nie psuć!!!

var n=5;
for(var i=0; i<=n; i++)
	if (i%2==1)
		{console.log(i + "-nieparzysta");
		} 
		else 
		{console.log(i + "-parzysta");}


//Z 6 zrobione


for(var i=0; i<6; i++)
	{for(var j=0; j<2; j++) 
		{console.log("i="+i+", j="+j);} 
	}
	
	
	
//Z 7 Przepisane
var size = 5;
var lineOfStars = "";
for(var i = 0; i < size; i++) {
    lineOfStars = "";
    for(var j = 0; j < size; j++) {
        lineOfStars = lineOfStars + "*";
    }
  console.log(" ");
  console.log(lineOfStars);
}

//Z 8 zrobione

var n = 5;
var m = 1;
var lineOfStars = "";
     
     
for(var i=0; i < m ; i++) {
    for(var j = 0; j < n; j++) {
        lineOfStars = lineOfStars + "* ";

		console.log(lineOfStars);
    }
}

