var favNumber=3;
console.log(favNumber);
console.log(typeof favNumber);
// Zmienna typu number przechowuje wartość 3, konsola wypisała "3 number"

var basicString="abc";
console.log(basicString);
console.log(typeof basicString);
//Zmienna typu string przechowuje wartość abc, konsola wypisała "abc"

var numberStringer="3+abc";
console.log(numberStringer);
console.log(typeof numberStringer);
//Zmienna typu string przechowuje wartość 3+abc, konsola wypisała "3+abc"


var prawda=true;
console.log(prawda);
console.log(typeof prawda);
//Zmienna typu boolean przechowuje wartość true, konsola wypisała "true, boolean"

var special=null;
console.log(null);
console.log(typeof null);
//Zmienna typu specjalnego przechowuje wartość null, konsola wypisała "null, object"



var number1=10;
console.log(number1);
var number2=7;
console.log(number2);
var result=0;
console.log(result);
var result2= number1+number2;
console.log(result2);

//Konsola wypisała kolejno wartości: 10, 7, 0, 17

var pusta;
console.log(pusta);

//Konsola wypiała "undefined"
