var prawda=true;
console.log(prawda);

var falsz=false;
console.log(falsz);

prawda==falsz

//Konsola wypisała kolejno wartości "true, false, false"


var number1=159;
console.log(number1);

var number2=2;
console.log(number2);

var resultModulo=0;
console.log(resultModulo);

resultModulo=number1%number2

//Konsola wypisała kolejno wartości "159, 2, 0, 1"

var basicString1="Warszawa";
console.log(basicString1);

var basicString2="Kraków i Poznań";
console.log(basicString2);

var basicString3="Lublin i Gdańsk";
console.log(basicString3);

var joinedStrings=""
console.log(joinedStrings);

joinedStrings=basicString1+basicString2+basicString3

//Konsola wypisała kolejno wartości "Warszawa", "Kraków i Poznań", "Lublin i Gdańsk", potem pustą linijkę, a potem "WarszawaKraków i PoznańLublin i Gdańsk"

var myNumber = 4;
console.log(myNumber);

var myString = "4";
console.log(myString);

myNumber==myString
//Konsola wypisała kolejno wartości "4, 4, true" znaczy, że wartość zmiennych jest taka sama (typ nie jest porównywany)

myNumber===myString
//Konsola wypisała kolejno wartości "4, 4, false" znaczy, że type zmiennych jest różny (porównywane są zarówno typ, jak i wartość)


var counter = 145;
console.log(counter);

counter = counter-1
//Konsola wypisała kolejno wartości "145, 144" 


counter = counter+1
//Konsola wypisała kolejno wartości "146, 146" 

var number1 = 133;
console.log(number1);

var number2 = 100;
console.log(number2);

var result = null;
console.log(result);
//Konsola wypisała kolejno wartości "133, 100 i null" 

result=number1>number2

//Konsola wypisała kolejno wartości "133, 100 i true", przy czym poprzednia linijka deklarująca wartość null w zmiennej result została pominięta (chociaż jak się nie pominie to też jest dobrze)
