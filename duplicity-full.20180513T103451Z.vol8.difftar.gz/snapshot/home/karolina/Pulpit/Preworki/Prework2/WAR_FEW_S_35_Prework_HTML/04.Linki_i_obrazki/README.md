<img alt="Logo" src="http://coderslab.pl/svg/logo-coderslab.svg" width="400">

# HTML &ndash; linki i obrazki

1. W folderze **images** znajdziesz obrazek **frontend-backend.jpg**. Umieść go w pliku **index.html**. Ten element ma mieć dwa atrybuty:
    * tekst alternatywny, 
    * tytuł.

  ![Front-end & Back-end Developer](images/frontend-backend.jpg)

2. Na obrazku z pierwszego polecenia ustaw link do strony coderslab.pl. Kiedy użytkownik kliknie na obrazek, to strona powinna otworzyć się w nowej karcie (użyj odpowiedniego atrybutu).

## Potrzebujesz pomocy?
* [w3schools, atrybut target](https://www.w3schools.com/tags/att_a_target.asp)
* HTML i CSS &ndash; pre-work
